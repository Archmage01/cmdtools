﻿#ifndef  __PUBLICKBASE_H__
#define  __PUBLICKBASE_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef signed char          int8_t;
typedef unsigned char       uint8_t;
typedef short               int16_t;
typedef unsigned short     uint16_t;
typedef int                 int32_t;
typedef unsigned int       uint32_t;
typedef signed   long long  int64_t;
typedef unsigned long long uint64_t;

/*-  printf   */
#define LOG(x,...)    do{ printf(x,##__VA_ARGS__); }while(0)

/*- moduel version  */
typedef struct _module_info_t{

    char     name[31]   ;	/**< moduel name */
    char     time[31]   ;	/**< compile time */
	uint8_t  major      ;	
	uint8_t  minor      ;	
    uint16_t patch      ;	
}module_info_t;



#ifdef __cplusplus
}
#endif

#endif
    
    
    
    