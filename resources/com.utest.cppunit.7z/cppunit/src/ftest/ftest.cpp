    #include <iostream>
    
    using  namespace  std ;
    
    class Solution {
    public:
        void test()
        {
    
        }
    };
    
    
    int  main(int argc,char **argv)
    {
        return 0 ;
    }
    
    