
    #include <cppunit/extensions/HelperMacros.h>
    #include <cppunit/extensions/TestFactoryRegistry.h>
    #include <cppunit/ui/text/TestRunner.h>
    
    #ifdef  CPPUNIT_TEST
    void  main()
    {
        CppUnit::TextUi::TestRunner runner;
        CppUnit::TestFactoryRegistry &registry = CppUnit::TestFactoryRegistry::getRegistry("cppunit_test_all");
        runner.addTest( registry.makeTest() );
        runner.run();
    }
    #endif
    