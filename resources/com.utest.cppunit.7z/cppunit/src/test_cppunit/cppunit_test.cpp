    #include <cppunit/extensions/HelperMacros.h>
    #include <iostream>
    
    
    extern "C" 
    {
    }
    #define CPPUNIT_EASSERT(a,b) CPPUNIT_ASSERT_EQUAL((int)a, (int)b)
    
    class  cppunit_test : public CPPUNIT_NS::TestFixture
    {
        CPPUNIT_TEST_SUITE(cppunit_test);
        CPPUNIT_TEST(cppunit_test_ver            );
        CPPUNIT_TEST_SUITE_END();
    
    public:
        cppunit_test();
        virtual ~cppunit_test();
        virtual void setUp();
        virtual void tearDown();
        void cppunit_test_ver ();
    };
    
    cppunit_test::cppunit_test()
    {
    }
    cppunit_test::~cppunit_test()
    {
    }
    
    void cppunit_test::setUp()
    {
    }
    
    void cppunit_test::tearDown()
    {
    }
    
    void cppunit_test::cppunit_test_ver()
    {
    }
    
    //将TestSuite注册到一个名为alltest的TestSuite中
    CPPUNIT_TEST_SUITE_NAMED_REGISTRATION(  cppunit_test,"cppunit_test_all");
    